﻿namespace MTSahilKumar
{
    public class HourlyEmployee : Employee
    {
        public double HoursWorked { get; set; }
        public double HourlyWage { get; set; }

    }
}
